# flask_study

추천 알고리즘 구현을 위한 flask서버

## 학습한 내용

1. flask run

2. Routing

3. var routing

4. json return

## 필요한 내용

1. MySQL과 연동

2. MongoDB와 연동?

3. 추천 알고리즘 요청 동시에 오면 동시 처리?

자카드 알고리즘?

협업필터링

아이템based 추천

KNN
